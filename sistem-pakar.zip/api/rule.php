<?php
// api/rule.php - CRUD endpoint for Rules
// Skema baru: gejala disimpan di tabel pivot rule_gejala (bukan JSON gejala_ids)
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    // ── GET: Ambil semua rule beserta gejala-nya (JOIN ke rule_gejala & gejala) ──
    case 'GET':
        // Ambil semua rule sekaligus detail kerusakannya
        $stmtRule = $pdo->query("
            SELECT r.id, r.kerusakan_id, k.kode AS kode_kerusakan, k.nama AS nama_kerusakan
            FROM rule r
            JOIN kerusakan k ON k.id = r.kerusakan_id
            ORDER BY r.id ASC
        ");
        $rules = $stmtRule->fetchAll();

        // Untuk setiap rule, ambil daftar gejala dari tabel pivot rule_gejala
        $stmtGejala = $pdo->prepare("
            SELECT g.id, g.kode, g.nama, g.bobot
            FROM rule_gejala rg
            JOIN gejala g ON g.id = rg.gejala_id
            WHERE rg.rule_id = ?
            ORDER BY g.id ASC
        ");

        $data = [];
        foreach ($rules as $rule) {
            $stmtGejala->execute([(int)$rule['id']]);
            $gejalaList = $stmtGejala->fetchAll();

            // Format gejalaIds sebagai array integer (kompatibel dengan frontend lama)
            $gejalaIds = array_map(fn($g) => (int)$g['id'], $gejalaList);

            $data[] = [
                'id'            => (int)$rule['id'],
                'kerusakanId'   => (int)$rule['kerusakan_id'],
                'kodeKerusakan' => $rule['kode_kerusakan'],
                'namaKerusakan' => $rule['nama_kerusakan'],
                'gejalaIds'     => $gejalaIds,
                'gejalaDetail'  => array_map(fn($g) => [
                    'id'    => (int)$g['id'],
                    'kode'  => $g['kode'],
                    'nama'  => $g['nama'],
                    'bobot' => (float)$g['bobot'],
                ], $gejalaList),
            ];
        }
        echo json_encode($data);
        break;

    // ── POST: Tambah rule baru + isi pivot rule_gejala ──────────────────────────
    case 'POST':
        $input      = getJsonInput();
        $kerusakanId = $input['kerusakanId'] ?? null;
        $gejalaIds   = $input['gejalaIds']   ?? [];

        if (empty($kerusakanId) || empty($gejalaIds) || !is_array($gejalaIds)) {
            http_response_code(400);
            echo json_encode(['error' => 'Kerusakan dan Gejala wajib dipilih']);
            exit();
        }

        // Cek apakah rule untuk kerusakan ini sudah ada
        $check = $pdo->prepare("SELECT id FROM rule WHERE kerusakan_id = ?");
        $check->execute([$kerusakanId]);
        if ($check->fetch()) {
            http_response_code(400);
            echo json_encode(['error' => 'Rule untuk kerusakan ini sudah ada']);
            exit();
        }

        // Validasi semua gejala_id yang dikirim benar-benar ada di tabel gejala
        $placeholders = implode(',', array_fill(0, count($gejalaIds), '?'));
        $validCheck   = $pdo->prepare("SELECT COUNT(*) AS cnt FROM gejala WHERE id IN ($placeholders)");
        $validCheck->execute(array_values($gejalaIds));
        $validCount = (int)$validCheck->fetchColumn();
        if ($validCount !== count($gejalaIds)) {
            http_response_code(400);
            echo json_encode(['error' => 'Terdapat gejala_id yang tidak valid']);
            exit();
        }

        // Mulai transaksi supaya rule + pivot insert atomik
        $pdo->beginTransaction();
        try {
            // Insert ke tabel rule (gejala_ids_deprecated diisi null / string kosong)
            $stmtRule = $pdo->prepare("INSERT INTO rule (kerusakan_id, gejala_ids_deprecated) VALUES (?, '')");
            $stmtRule->execute([$kerusakanId]);
            $newRuleId = (int)$pdo->lastInsertId();

            // Insert ke pivot rule_gejala
            $stmtPivot = $pdo->prepare("INSERT INTO rule_gejala (rule_id, gejala_id) VALUES (?, ?)");
            foreach ($gejalaIds as $gId) {
                $stmtPivot->execute([$newRuleId, (int)$gId]);
            }

            $pdo->commit();
            echo json_encode([
                'success' => true,
                'message' => 'Rule berhasil ditambahkan',
                'data'    => ['id' => $newRuleId, 'kerusakanId' => (int)$kerusakanId, 'gejalaIds' => $gejalaIds],
            ]);
        } catch (Exception $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['error' => 'Gagal menyimpan rule: ' . $e->getMessage()]);
        }
        break;

    // ── PUT: Update rule → hapus pivot lama, insert pivot baru ─────────────────
    case 'PUT':
        $id          = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $input       = getJsonInput();
        $kerusakanId = $input['kerusakanId'] ?? null;
        $gejalaIds   = $input['gejalaIds']   ?? [];

        if ($id <= 0 || empty($kerusakanId) || empty($gejalaIds) || !is_array($gejalaIds)) {
            http_response_code(400);
            echo json_encode(['error' => 'ID, Kerusakan, dan Gejala wajib diisi']);
            exit();
        }

        // Validasi semua gejala_id yang dikirim benar-benar ada di tabel gejala
        $placeholders = implode(',', array_fill(0, count($gejalaIds), '?'));
        $validCheck   = $pdo->prepare("SELECT COUNT(*) AS cnt FROM gejala WHERE id IN ($placeholders)");
        $validCheck->execute(array_values($gejalaIds));
        $validCount = (int)$validCheck->fetchColumn();
        if ($validCount !== count($gejalaIds)) {
            http_response_code(400);
            echo json_encode(['error' => 'Terdapat gejala_id yang tidak valid']);
            exit();
        }

        $pdo->beginTransaction();
        try {
            // Update kerusakan di tabel rule
            $stmtRule = $pdo->prepare("UPDATE rule SET kerusakan_id = ? WHERE id = ?");
            $stmtRule->execute([$kerusakanId, $id]);

            // Hapus pivot lama lalu insert yang baru (replace strategy)
            $pdo->prepare("DELETE FROM rule_gejala WHERE rule_id = ?")->execute([$id]);

            $stmtPivot = $pdo->prepare("INSERT INTO rule_gejala (rule_id, gejala_id) VALUES (?, ?)");
            foreach ($gejalaIds as $gId) {
                $stmtPivot->execute([$id, (int)$gId]);
            }

            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Rule berhasil diperbarui']);
        } catch (Exception $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['error' => 'Gagal memperbarui rule: ' . $e->getMessage()]);
        }
        break;

    // ── DELETE: Hapus rule (pivot rule_gejala ikut terhapus via ON DELETE CASCADE) ──
    case 'DELETE':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'ID tidak valid']);
            exit();
        }

        // rule_gejala akan otomatis terhapus karena FK ON DELETE CASCADE
        $stmt = $pdo->prepare("DELETE FROM rule WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(['success' => true, 'message' => 'Rule berhasil dihapus']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>
